<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    protected $fillable = ['receiver_id', 'message','sender_id'];

    public function user()
    {
        return $this->belongsTo('App\User','sender_id');
    }

    public function user_receive()
    {
        return $this->belongsTo('App\User','receiver_id');
    }
}
