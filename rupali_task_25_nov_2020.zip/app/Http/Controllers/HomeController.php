<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Message;
use Auth;
use Log;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Users=User::all();
        $userId = Auth::id();
        $sent_messages = Message::where('sender_id',$userId)->count();
        $recieved_messages = Message::where('receiver_id',$userId)->count();

        return view('home',compact('Users','sent_messages','recieved_messages'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'user' => 'required',
            'message' => 'required',
        ]);
        try{
            $message = $request->all();
            $userId = Auth::id();
            $message['receiver_id'] = $request->user;
            Log::info($message['receiver_id']);
            $message['sender_id'] = $userId;
            $Message = Message::create($message);
            return redirect()->back()->with('flash_success', 'Message has been sent');   
        } 
        catch (Exception $e) {
            return back()->with('flash_error', 'Not sent');
        }

    }

    public function inbox()
    {
        $userId = Auth::id();
        $sent_messages = Message::where('sender_id',$userId)->count();
        $recieved_messages = Message::where('receiver_id',$userId)->count();
        $messages = Message::with('user')->where('receiver_id',$userId)->get();

        return view('inbox',compact('messages','sent_messages','recieved_messages'));
    }

    public function sent()
    {
        $userId = Auth::id();
        $sent_messages = Message::where('sender_id',$userId)->count();
        $recieved_messages = Message::where('receiver_id',$userId)->count();
        $messages = Message::with('user_receive')->where('sender_id',$userId)->get();

        return view('sent',compact('messages','sent_messages','recieved_messages'));
    }
}
