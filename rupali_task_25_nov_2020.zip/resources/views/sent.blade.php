@extends('layouts.app')

@section('content')

<div class="sidenav">
  <a href="/inbox">Inbox({{$recieved_messages}})</a>
  <a href="/sent">Sent({{$sent_messages}})</a>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-heading">Messages</div>
          <div class="panel-body">
            <div class="container">
            <table>
                <thead>
                    <tr>
                        <th>Receiver</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($messages as $message)
                    <tr>
                    @if(empty($message->user_receive))
                        <td>N/A</td>
                    @else
                    <td>{{ $message->user_receive->name }}</td> 
                    @endif  
                        <td>{{ $message->message }}</td>
                    </tr>
                    @endforeach
                </tbody>
              
            </table>
            </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 49px 0px 0px 27px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 50%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>