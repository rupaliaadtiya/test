<?php $__env->startSection('content'); ?>
<div class="sidenav">
  <a href="/inbox">Inbox(<?php echo e($recieved_messages); ?>)</a>
  <a href="/sent">Sent(<?php echo e($sent_messages); ?>)</a>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-heading">Dashboard</div>
          <div class="panel-body">
            <div class="container">
              <h2>Compose Message</h2>
              <?php if(Session::has('flash_success')): ?>

              <div style="width: 50%" class="alert alert-info"><?php echo e(Session::get('flash_success')); ?></div>

            <?php endif; ?>
            <?php if(Session::has('flash_error')): ?>

            <div style="width: 50%" class="alert alert-info"><?php echo e(Session::get('flash_error')); ?></div>

            <?php endif; ?>
              <form action = "/create" method="POST">
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
              <label for="email">Users:</label>
              <select style="width: 50%" class="form-control input" name="user" required>
                  <?php $__empty_1 = true; $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                  <option value="<?php echo e($User->id); ?>"><?php echo e($User->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                  <option> -</option>
                  <?php endif; ?>
              </select>
              </div>
              <div class="form-group">
                  <textarea style="width: 50%" id="message" name="message" rows="4" cols="50" placeholder="Type message here...">
                
                  </textarea>
                </div>
                <button type="submit" class="btn btn-default">Submit</button>
              </form>
            </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 49px 0px 0px 27px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
}

@media  screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>