<?php
use Phppot\DataSource;

require_once 'DataSource.php';
$db = new DataSource();
$conn = $db->getConnection();

if (isset($_POST["import"])) {
    
    $fileName = $_FILES["file"]["tmp_name"];
    
    if ($_FILES["file"]["size"] > 0) {
        
        $file = fopen($fileName, "r");
        
        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
            
            $userName = "";
            if (isset($column[0])) {
                $userName = mysqli_real_escape_string($conn, $column[0]);
            }
            $password = "";
            if (isset($column[1])) {
                $password = mysqli_real_escape_string($conn, $column[1]);
            }
            $firstName = "";
            if (isset($column[2])) {
                $firstName = mysqli_real_escape_string($conn, $column[2]);
            }
            $lastName = "";
            if (isset($column[3])) {
                $lastName = mysqli_real_escape_string($conn, $column[3]);
            }
            
            $sqlInsert = "INSERT into users (name,email,mobile,address)
                   values (?,?,?,?)";
            $paramType = "ssss";
            $paramArray = array(
                $userName,
                $password,
                $firstName,
                $lastName
            );

            $insertId = $db->insert($sqlInsert, $paramType, $paramArray);
            
            if (! empty($insertId)) {
                $type = "success";
                $message = "CSV Data Imported into the Database";
            } else {
                $type = "error";
                $message = "Problem in Importing CSV Data";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>

<head>
<script src="jquery-3.2.1.min.js"></script>
<script src="main.js"></script>
<link href="style.css" rel="stylesheet">
</head>

<body>
    <h2>Import CSV</h2>

    <div id="response"
        class="<?php if(!empty($type)) { echo $type . " display-block"; } ?>">
        <?php if(!empty($message)) { echo $message; } ?>
        </div>
    <div class="outer-scontainer">
        <div class="row">

            <form class="form-horizontal" action="" method="post"
                name="frmCSVImport" id="frmCSVImport"
                enctype="multipart/form-data">
                <div class="input-row">
                    <label class="col-md-4 control-label">Choose CSV
                        File</label> <input type="file" name="file"
                        id="file" accept=".csv">
                    <button type="submit" id="submit" name="import"
                        class="btn-submit">Import</button>
                    <br />

                </div>

            </form>

        </div>
               <?php
            $sqlSelect = "SELECT * FROM users";
            $result = $db->select($sqlSelect);
            if (! empty($result)) {
                ?>
                <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a name">
            <table id='userTable'>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>Address</th>

                </tr>
            </thead>
<?php
                
                foreach ($result as $row) {
                    ?>
                    
                <tbody>
                <tr>
                    <td><?php  echo $row['name']; ?></td>
                    <td><?php  echo $row['email']; ?></td>
                    <td><?php  echo $row['mobile']; ?></td>
                    <td><?php  echo $row['address']; ?></td>
                </tr>
                    <?php
                }
                ?>
                </tbody>
        </table>
        <?php } ?>
    </div>

</body>

</html>