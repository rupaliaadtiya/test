<?php echo e($slot); ?>

<?php /**PATH /home/homepageit/my_admin_System/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>