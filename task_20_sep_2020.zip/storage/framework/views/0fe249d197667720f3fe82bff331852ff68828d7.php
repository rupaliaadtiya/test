<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                   <h4>Create new post!</h4>

                <form action="<?php echo e(url('/create_post')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <label for="title">Title:</label><br>
                <input type="text" id="title" name="title"><br>
                <label for="description">Description:</label><br>
                <textarea id="description" name="description" rows="4" cols="50">
                </textarea><br>
                <input type="submit" value="Submit">
                </form> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homepageit/my_admin_System/resources/views/home.blade.php ENDPATH**/ ?>