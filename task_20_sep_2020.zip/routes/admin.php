<?php
/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/

Route::get('/', 'AdminController@dashboard')->name('index');
Route::get('/dashboard', 'AdminController@dashboard')->name('dashboard');

Route::resource('user', 'Resource\UserAdminResource');

 Route::group(['as' => 'user.'], function () {
     Route::get('user/{id}/disapprove', 'Resource\UserAdminResource@disapprove')->name('disapprove');
     Route::post('user/{id}/edit', 'Resource\UserAdminResource@update')->name('update');
 
});

