<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Log;
use App\Category; 
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = Category::get();
        return view('home',compact('categories'));
    }

    public function category()
    {
        return view('category');
    }

    public function add(Request $request)
    {
        try{
            
            $category = $request->all();
            Log:info($category);
            $category['category'] = $category['category'];
            $category['subcategory'] = $category['subcategory'];
            $category = Category::create($category);

            return redirect()->route('home')->with('flash_success','Saved Successfully');

        } 
        catch (Exception $e) {
            
            return back()->with('flash_error', 'Not Found');
        }
    }
    public function edit($id)
    {
        $data = Category::findOrFail($id);
        return view('edit')->with('data',$data);
    }

    public function editcategory(Request $request){
        $data = $request->all();
        $category = Category::findOrFail($data['id']);
        $category['category'] = $data['category'];
        if(!empty($data['subcategory'])){
        $category['subcategory'] = $data['subcategory'];
        }
        $category->save();
       
        return redirect()->route('home')->with('flash_success','Saved Successfully');
     
    }
}
