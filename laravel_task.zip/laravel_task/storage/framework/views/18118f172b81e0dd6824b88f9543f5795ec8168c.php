<html>

<head>

    <title>Laravel Multiple Select Dropdown with Checkbox Example - ItSolutionStuff.com</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

    <style type="text/css">

        .dropdown-toggle{

            height: 40px;

            width: 400px !important;

        }

    </style>

</head>

<body>

    <div class="container">

        <div class="row">

            <div class="col-md-8 offset-2 mt-5">

                <div class="card">

                    <div class="card-header bg-info">

                        <h4 class="text-white">Update Category</h4>

                    </div>

                    <div class="card-body">

                        <form method="post" action="<?php echo e(url('edit')); ?>" enctype="multipart/form-data">

                        <?php echo e(csrf_field()); ?>

                        <input type="hidden"  name="id" value="<?php echo e($data->id); ?>">
                            <div class="form-group">

                                <label>Category</label>

                                <input type="text" name="category" value="<?php echo e($data->category); ?>" class="form-control"/>

                            </div>  

                    
                            <div class="">

                                <label><strong>Select Subcategory :</strong></label><br/>

                                <select class="selectpicker" multiple data-live-search="true" name="subcategory[]">

                                  <option value="test">test</option>

                                  <option value="test1">test1</option>

                                  <option value="test2">test2</option>

                                  <option value="test3">test3</option>

                                  <option value="test4">test4</option>

                                  <option value="test5">test5</option>

                                </select>

                            </div>

                            

                            <div class="text-center" style="margin-top: 10px;">

                                <button type="submit" class="btn btn-success">Update</button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>    

</body>

  

<!-- Initialize the plugin: -->

<script type="text/javascript">

    $(document).ready(function() {

        $('select').selectpicker();

    });

</script>

  

</html>